workpath = ''
confpath = ''
userpath = ''
app = None
mainframe = None
starting = False
pref = None
