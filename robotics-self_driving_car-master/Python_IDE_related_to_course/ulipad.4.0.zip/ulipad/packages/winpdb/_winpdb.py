import winpdb

winpdb.main()
